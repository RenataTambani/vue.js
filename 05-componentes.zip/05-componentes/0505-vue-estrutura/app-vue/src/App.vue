<template>
  <div>
    <div id="app">{{mensagem}}</div>
    <HeaderPrincipal/>
  </div>
</template>

<script>
export default {
  data() {
    return {
      mensagem: "Essa é uma mensagem"
    };
  }
};
</script>

<style>
</style>
