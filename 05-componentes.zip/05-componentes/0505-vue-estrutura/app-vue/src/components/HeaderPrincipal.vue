<template>
  <nav>
    <ul>
      <li>Home</li>
      <li>Serviços</li>
      <li>Contato</li>
    </ul>
  </nav>
</template>

<script>
export default {
  name: "HeaderPrincipal"
};
</script>

<style>
</style>
