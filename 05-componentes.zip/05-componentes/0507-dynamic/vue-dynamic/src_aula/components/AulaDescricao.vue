<template>
  <div>
    <p>Essa é a aula principal do curso.</p>
  </div>
</template>

<script>
export default {
  name: "AulaDescricao"
};
</script>

<style>
</style>
