<template>
  <div>
    <h1>Serviços</h1>
    <ul>
      <li>UX/UI Design</li>
      <li>Front end</li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "ServicosEmpresa"
};
</script>

<style>
</style>
