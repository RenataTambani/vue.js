<template>
  <div>
    <h1>Sobre a Empresa</h1>
    <p>Essa é a empresa principal.</p>
  </div>
</template>

<script>
export default {
  name: "SobreEmpresa"
};
</script>

<style>
</style>
