<template>
  <div>
    <h1>Contato</h1>
    <input type="text">
  </div>
</template>

<script>
export default {
  name: "ContatoEmpresa"
};
</script>

<style>
</style>
